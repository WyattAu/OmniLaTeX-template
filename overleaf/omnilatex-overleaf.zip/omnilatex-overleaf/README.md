# OmniLaTeX on Overleaf

A modular, engineering-grade LaTeX document class.

## Setup

1. Upload this zip to Overleaf (Menu → New Project → Upload Project)
2. Set compiler to **LuaLaTeX** (Menu → Compiler → LuaLaTeX)
3. Click **Recompile**

## Directory Structure

```
main.tex              Your document (edit this)
omnilatex.cls         Document class
lib/                  Module library (do not edit)
config/               Document settings
bib/                  Bibliography files
```

## Customization

Edit `\documentclass` options in `main.tex`:

```latex
\documentclass[doctype=thesis, language=english]{omnilatex}
```

See the full documentation at https://github.com/WyattAu/OmniLaTeX-template
